<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wycieczki po europie</title>
    <link rel="stylesheet" href="styl4.css">
</head>
<body>
    <header></header>
    <div id="list"></div>
    <h3>wycieczki na które są wolne miejcsa </h3>

    <ul>
        <?php
        $db = new mysqli('localhost', 'root', '', 'biuro');
        $sql = "SELECT id, dataWyjazdu, cel, cena FROM wycieczki WHERE dostepna = 1";
        $result = $db->query($sql);
        while($row = $result->fetch_assoc()) {
            echo "<li>";
            $id = $row['id'];
            $data = $row['dataWyjazdu'];
            $cel = $row['cel'];
            $cena = $row['cena'];
            echo "$id. dnia $data do $cel, cena: $cena";
            echo "</li>";
        }
        $db->close();
        ?>
        </ul>
    <main>
<div id="left">
<h2>Bestselery</h2>
            <table>
                <tr>
                    <td>Wenecja</td>
                    <td>kwiecień</td>
                </tr>
                <tr>
                    <td>Londyn</td>
                    <td>lipiec</td>
                </tr>
                <tr>
                    <td>Rzym</td>
                    <td>wrzesień</td>
                </tr>
            </table>
        </div>
<div id="center">
<h2> nasze zdjecia</h2>

<?php
            $db = new mysqli('localhost', 'root', '', 'biuro');
            $sql = "SELECT nazwaPliku, podpis FROM zdjecia ORDER BY podpis DESC";
            $result = $db->query($sql);
            while($row = $result->fetch_assoc()) {
                $nazwa = $row['nazwaPliku'];
                $podpis = $row['podpis'];
                //echo '<img src="'.$nazwa.'" alt="'.$podpis.'">';
                echo "<img src=\"$nazwa\" alt=\"$podpis\">";
            }
            $db->close();
            ?>
            </div>
<div id="right">
<h2>skontaktuj sie </h2>
<a href="mailto: turyst@dasdawd.pl">napisz do nas</a>
<p> telefon 3312312313.</p>
</div>
    </main>
    <footer><p>Stronę wykonał: 00000000000</p></footer>
</body>
</html>